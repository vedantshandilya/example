package com.cg.oms.service;

import com.cg.oms.entity.Address;
import com.cg.oms.repository.IAddressRepository;
import com.cg.oms.repository.AddressRepository;

public class AddressService implements IAddressService {
	private IAddressRepository repo;
	
	public AddressService() {
		repo = new AddressRepository();
	}
	
	public Address addAddress(Address address) {
		return repo.addAddress(address);
	}
	public int deleteAddressById(int addressId) {
		return repo.deleteAddressById(addressId);
		
	}
	public int deleteAddressByCity(String city) {
		return repo.deleteAddressByCity(city);
	}
	public boolean updateAddress(Address newAddress) {
		return repo.updateAddress(newAddress);
	}
	public Address getAddressById(int addressId) {
		return repo.getAddressById(addressId);
	}

}
