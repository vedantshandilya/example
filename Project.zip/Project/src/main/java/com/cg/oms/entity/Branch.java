package com.cg.oms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="branch_details")
public class Branch 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Branch_Id ")
	private int branchId;
	
	@Column(name="Branch_Name ")
	private String branchName;
	
	@Column(name=" Branch_Description ")
	private String branchDescription;
	
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchDescription() {
		return branchDescription;
	}
	public void setBranchDescription(String branchDescription) {
		this.branchDescription = branchDescription;
	}
	@Override
	public String toString() {
		return "Branch [branchId=" + branchId + ", branchName=" + branchName + ", branchDescription="
				+ branchDescription + "]";
	}
	
}
