package com.cg.oms.service;

import java.util.ArrayList;

import com.cg.oms.entity.Branch;
import com.cg.oms.repository.IBranchRepository;
import com.cg.oms.repository.BranchRepository;

public class BranchService implements IBranchService {
	private IBranchRepository repo;
	
	public BranchService() {
		repo = new BranchRepository();
	}
	public boolean addBranch( Branch branch) {
		return repo.addBranch(branch);
	}
	public ArrayList<Branch> viewAllBranchDetails() {
		return repo.viewAllBranchDetails();
	}
	public  ArrayList<Branch> getBranchDetailsByName(String branchName) {
		return repo.getBranchDetailsByName(branchName);
	}
	public int deleteBranchById(int branchId) {
		return repo.deleteBranchById(branchId);
	}
	public Branch getBranchById(int branchId) {
		return repo.getBranchById(branchId);
	}
	public int deleteBranchByName(String branchName) {
		return repo.deleteBranchByName(branchName);
	}
	public int  updateBranch(Branch branch) {
		return repo.updateBranch(branch);
	}
}
