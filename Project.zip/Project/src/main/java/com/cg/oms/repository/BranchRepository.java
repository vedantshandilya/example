package com.cg.oms.repository;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

//import com.cg.oms.entity.Address;
import com.cg.oms.entity.Branch;
import javax.persistence.Query;

public class BranchRepository implements IBranchRepository {
	private EntityManagerFactory factory;
	
	public BranchRepository() {
		factory=Persistence.createEntityManagerFactory("saurav");
	}
	public boolean addBranch(Branch branch)
	{
		EntityManager em=factory.createEntityManager();
		
		EntityTransaction txn=em.getTransaction();
		try {
			txn.begin();
			em.persist(branch);
			txn.commit();
			return true;
		} finally {
			em.close();
		}
	}
	public ArrayList<Branch> viewAllBranchDetails()
	{
		EntityManager em= factory.createEntityManager();
		
		try {
		Query query=em.createQuery("from Branch");
		return (ArrayList<Branch>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}
	public  ArrayList<Branch> getBranchDetailsByName(String branchName) {
		EntityManager em=factory.createEntityManager();
		try {
			Query query=em.createQuery("Select * from branch where Branch_Name=" + branchName);
			return (ArrayList<Branch>) query.getResultList();
		} finally {
			em.close();
		}
	}
	public int deleteBranchById(int branchId) {
		EntityManager em=factory.createEntityManager();
		EntityTransaction txn=em.getTransaction();
		
		try {
			txn.begin();
			Branch branch = em.find(Branch.class, branchId);
			
			/*if(address==null)
				throw new BranchNotFoundException("No branch found with Id: "+ branchId);*/
			
			em.remove(branch);
			txn.commit();
			
			
			return branchId;
		}
		finally {
			em.close();
		}
	}
	public Branch getBranchById(int branchId) {
		EntityManager em=factory.createEntityManager();
		try {
			Branch branch = em.find(Branch.class, branchId);
			/*if (branch == null)
				throw new AddressNotFoundException("No address found with Id: " + addressId);*/
			return branch;
		} finally {
			em.close();
		}
	}
	public int deleteBranchByName(String branchName) {
		EntityManager em=factory.createEntityManager();
		EntityTransaction txn=em.getTransaction();
		
		try {
			txn.begin();
			Branch branch = em.find(Branch.class, branchName);
			
			/*if(branch==null)
				throw new BranchNotFoundException("No branch found with name: "+ branchName);*/
			
			em.remove(branch);
			txn.commit();
			
			
			return 0;
		}
		finally {
			em.close();
		}
	}
	public int  updateBranch(Branch branch) {
		EntityManager em=factory.createEntityManager();
		
		EntityTransaction txn=em.getTransaction();
		try {
			txn.begin();
			em.merge(branch);
			txn.commit();
			return 0;
		} finally {
			em.close();
		}	
		
	}

}
