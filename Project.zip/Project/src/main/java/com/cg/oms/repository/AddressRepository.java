package com.cg.oms.repository;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.oms.entity.Address;
//import com.cg.oms.service.AddressNotFoundException;
import com.cg.oms.service.IAddressService;

public class AddressRepository implements IAddressRepository {
	private EntityManagerFactory factory;

	public AddressRepository() {
		factory=Persistence.createEntityManagerFactory("saurav");
	}

	public Address addAddress(Address address) {
		EntityManager em=factory.createEntityManager();

		EntityTransaction txn=em.getTransaction();
		try {
			txn.begin();
			em.merge(address);
			txn.commit();
			return address;
		} finally {
			em.close();
		}
	}

	public int deleteAddressById(int addressId) {
		EntityManager em=factory.createEntityManager();
		EntityTransaction txn=em.getTransaction();

		try {
			txn.begin();
			Address address = em.find(Address.class, addressId);

			/*if(address==null)
					throw new AddressNotFoundException("No address found with Id: "+ addressId);*/

			em.remove(address);
			txn.commit();


			return 0;
		}
		finally {
			em.close();
		}

	}
	public int deleteAddressByCity(String city) {
		EntityManager em=factory.createEntityManager();

		EntityTransaction txn=em.getTransaction();
		try {
			txn.begin();
			Address address= em.find(Address.class, city);

			/*if(address==null)
				throw new AddressNotFoundException("No city found with city name: "+ city);*/

			em.remove(address);
			txn.commit();

			return 0;
		}
		finally {
			em.close();
		}

	}

	public boolean updateAddress(Address newAddress) {
		EntityManager em=factory.createEntityManager();

		EntityTransaction txn=em.getTransaction();
		try {
			txn.begin();
			em.merge(newAddress);
			txn.commit();
			return true;
		} finally {
			em.close();
		}

	}

	public Address getAddressById(int addressId) {
		EntityManager em=factory.createEntityManager();
		try {
			Address address = em.find(Address.class, addressId);
			/*if (address == null)
				throw new AddressNotFoundException("No address found with Id: " + addressId);*/
			return address;
		} finally {
			em.close();
		}

	}
}

