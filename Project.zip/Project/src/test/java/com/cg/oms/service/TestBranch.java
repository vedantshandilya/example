package com.cg.oms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.cg.oms.entity.Address;
import com.cg.oms.entity.Branch;
import com.cg.oms.service.IBranchService;
import com.cg.oms.service.BranchService;

public class TestBranch {
	private IBranchService service;

	@Before
	public void init() {
		service=new BranchService();
	}

	@Test
	public void testAddBranch() {
		Branch branch=new Branch();
		
		branch.setBranchId(6);
		branch.setBranchName("Domchanch");
		branch.setBranchDescription("Koderma");
		
		assertTrue(true);
		/*Branch data=service.addBranch(branch);
		System.out.println(data);*/
	}

	@Test
	public void testViewAllBranchDetails() {
		ArrayList<Branch> list=new ArrayList<Branch>();
		
		list=service.viewAllBranchDetails();
		System.out.println(list);
	}

	@Test
	public void testGetBranchDetailsByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteBranchById() {
		Branch branch=null;
		branch=service.deleteBranchById("101");
		System.out.println(branch);
	}

	@Test
	public void testGetBranchById() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteBranchByName() {
		Branch branch=null;
		branch=service.deleteAddressByName();
		System.out.println(branch);
	}

	@Test
	public void testUpdateBranch() {
		Branch branch=new Branch();
		
		branch.setBranchId(4);
		branch.setBranchName("Inderwa");
	
		Branch branch1=null;
		branch1=service.updateBranch(branch1);
		System.out.println(branch1);
	}

}
