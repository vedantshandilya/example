package com.cg.oms.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
//import junit.framework.*;

import com.cg.oms.entity.Address;
import com.cg.oms.service.IAddressService;
import com.cg.oms.service.AddressService;

public class AddressTest {
	private IAddressService service;

	@Before
	public void init() {
		service = new AddressService();
	}

	@Test
	public void testAddAddress() {
		Address address=new Address();
		
		address.setAddressId(123);
		address.setCity("Domchanch");
		address.setDistrict("Koderma");
		address.setState("Jharkhand");
		address.setCountry("India");
		address.setZipcode("825410");
		address.setLandmark("Near PNB");
		service.addAddress(address);
		assertEquals(address, service.getAddressById(123));
		/*Address a = service.addAddress(address);
		System.out.println(a);*/
		
	}

	@Test
	public void testDeleteAddressById() {
		
		Address address=null;
		address=service.deleteAddressById();
		System.out.println(address);
	}

	@Test
	public void testDeleteAddressByCity() {
		Address address=null;
		address=service.deleteAddressByCity();
		System.out.println(address);
	}

	@Test
	public void testUpdateAddress() {
		Address address=new Address();
		
		address.setAddressId(123);
		address.setCity("Domchanch");
		address.setDistrict("Koderma");
		address.setState("Jharkhand");
		
		assertTrue(true);
		/*Address address1=null;
		address1=service.updateAddress(address);
		System.out.println(address1);*/
	}

	@Test
	public void testGetAddressById() {
		Address address = service.getAddressById(123);
			System.out.println(address);
			
		
		}
	}


